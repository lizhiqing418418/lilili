function result = process_data_small(data)
    % 初始参数
    job_rank = data(1);
    ope_rank = data(2);
    fa_num = 2;
    fa_rank = [1;2];
    n_op = 10;
    record_length = 1 + 2 * n_op;

    % 初始化 pro_time1 和 pro_time2
    pro_time1 = zeros(0, record_length);
    pro_time2 = zeros(0, record_length);

    % 解析数据（保持原有逻辑）
    if length(data) >= 6 + record_length
        temp = data(6:6 + record_length - 1);
        pro_time1 = [pro_time1; temp];
    end
    j = 6 + record_length;
    factory2_started = false;

    while j <= length(data)
        if factory2_started
            if j + record_length - 1 <= length(data)
                record = data(j:j + record_length - 1);
                pro_time2 = [pro_time2; record];
                j = j + record_length;
            else
                break;
            end
        else
            if data(j) == 2
                if j + 1 <= length(data) && data(j + 1) == 1
                    if j + record_length - 1 <= length(data)
                        record = data(j:j + record_length - 1);
                        pro_time1 = [pro_time1; record];
                        j = j + record_length;
                    else
                        break;
                    end
                else
                    if j + record_length <= length(data)
                        record_full = data(j:j + record_length);
                        record = record_full(2:end);
                        pro_time2 = [pro_time2; record];
                        factory2_started = true;
                        j = j + record_length + 1;
                    else
                        break;
                    end
                end
            else
                if j + record_length - 1 <= length(data)
                    record = data(j:j + record_length - 1);
                    pro_time1 = [pro_time1; record];
                    j = j + record_length;
                else
                    break;
                end
            end
        end
    end

    % 计算 mach_num
    mach_num = [size(pro_time1, 1); size(pro_time2, 1)];

    % 构造 mach_rank
    max_rows = max(mach_num);
    if size(pro_time1, 1) > 0
        row1 = pro_time1(:,1)';
        row1 = [row1, zeros(1, max_rows - length(pro_time1(:,1)))];
    else
        row1 = zeros(1, max_rows);
    end
    if size(pro_time2, 1) > 0
        row2 = pro_time2(:,1)';
        row2 = [row2, zeros(1, max_rows - length(pro_time2(:,1)))];
    else
        row2 = zeros(1, max_rows);
    end
    mach_rank = [row1; row2];

    % 构造 wo_num
    wo_num = 10 * (mach_rank ~= 0);

    % 处理时间（无需条件检查）
    c1 = pro_time1(:, 3:2:end);
    c2 = pro_time2(:, 3:2:end);


    pro_time = {{c1; c2}};


    % 返回结果
    result = struct('job_rank', job_rank, ...
                    'ope_rank', ope_rank, ...
                    'fa_num', fa_num, ...
                    'fa_rank', fa_rank, ...
                    'mach_num', mach_num, ...
                    'mach_rank', mach_rank, ...
                    'wo_num', wo_num, ...
                    'pro_time', pro_time);
end
