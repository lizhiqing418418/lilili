%% 初始化数据
data = [1 1 2 6 1 1 1 11 2 33 3 35 4 37 5 22 6 14 7 11 8 19 9 11 10 21 2 1 18 2 35 3 30 4 11 5 18 6 16 7 26 8 21 9 25 10 25 4 1 12 2 25 3 30 4 19 5 23 6 16 7 14 8 40 9 32 10 21 6 1 27 2 17 3 12 4 26 5 16 6 17 7 38 8 26 9 16 10 11 2 7 1 11 2 21 3 15 4 14 5 36 6 23 7 16 8 15 9 27 10 11 10 1 14 2 15 3 13 4 16 5 34 6 13 7 21 8 33 9 15 10 11];
%data=[1 2 2 8 1 3 1 29 2 29 3 65 4 40 5 58 6 27 7 62 8 46 9 31 10 53 5 1 71 2 39 3 38 4 52 5 78 6 65 7 76 8 29 9 38 10 34 6 1 62 2 37 3 30 4 95 5 38 6 49 7 48 8 34 9 46 10 29 2 7 1 58 2 51 3 51 4 45 5 30 6 88 7 27 8 40 9 66 10 52 8 1 89 2 29 3 66 4 32 5 44 6 47 7 34 8 31 9 43 10 62 9 1 31 2 28 3 45 4 74 5 30 6 28 7 30 8 31 9 36 10 47 10 1 39 2 44 3 29 4 49 5 39 6 33 7 46 8 29 9 79 10 38 11 1 78 2 39 3 43 4 32 5 68 6 36 7 32 8 88 9 31 10 37];
%data=[1 3 2 5 1 2 1 79 2 77 3 50 4 50 5 105 6 84 7 126 8 62 9 62 10 63 3 1 71 2 99 3 177 4 88 5 88 6 74 7 57 8 67 9 93 10 183 5 1 70 2 55 3 130 4 77 5 148 6 113 7 94 8 88 9 97 10 54 6 1 90 2 51 3 77 4 49 5 87 6 59 7 158 8 71 9 171 10 97 2 8 1 51 2 59 3 70 4 89 5 86 6 50 7 106 8 96 9 52 10 93];
% 提取开头的四个数据
job_rank = data(1);    % 第1个数据，job_rank
ope_rank = data(2);    % 第2个数据，ope_rank
fa_num=2;
fa_rank=[1;2];
% data(3) 和 data(4) 未使用，但保留

%% 设置记录长度
n_op = 10;              % 操作数为10
record_length = 1 + 2*n_op;  % 标准记录长度为21

%% 提取第一个工厂（pro_time1）的第一条记录
pro_time1 = [];   % 用矩阵存放工厂1的记录
temp = data(6:6+record_length-1); % data(6:26)
pro_time1 = [pro_time1; temp];

%% 从第26个数据开始依次判断剩余记录
pro_time2 = [];   % 用矩阵存放工厂2的记录
j = 6 + record_length;  % j = 27
factory2_started = false; % 标志位，表示工厂2的数据是否开始

while j <= length(data)
    if factory2_started
        % 工厂2已开始，所有后续记录均为工厂2，格式：[machine 1 x1 ... 10 x10]
        if j + record_length - 1 <= length(data)
            record = data(j:j+record_length-1);
            pro_time2 = [pro_time2; record];
            j = j + record_length;
        else
            warning('数据不足，无法按预期格式解析！');
            break;
        end
    else
        % 工厂2尚未开始，检查当前记录
        if data(j) == 2
            if j+1 <= length(data) && data(j+1) == 1
                % 工厂1记录：[2 1 x1 2 x2 ... 10 x10]
                if j + record_length - 1 <= length(data)
                    record = data(j:j+record_length-1);
                    pro_time1 = [pro_time1; record];
                    j = j + record_length;
                else
                    warning('数据不足，无法按预期格式解析！');
                    break;
                end
            else
                % 工厂2的第一条记录：[2 x 1 x1 ... 10 x10]，存储为 [x 1 x1 ... 10 x10]
                if j + record_length <= length(data)
                    record_full = data(j:j+record_length);
                    record = record_full(2:end);
                    pro_time2 = [pro_time2; record];
                    factory2_started = true;
                    j = j + record_length + 1; % 跳过22个元素
                else
                    warning('数据不足，无法按预期格式解析！');
                    break;
                end
            end
        else
            % 工厂1记录：[machine 1 x1 ... 10 x10]，machine != 2
            if j + record_length - 1 <= length(data)
                record = data(j:j+record_length-1);
                pro_time1 = [pro_time1; record];
                j = j + record_length;
            else
                warning('数据不足，无法按预期格式解析！');
                break;
            end
        end
    end
end

% Store the number of rows from pro_time1 and pro_time2 in mach_num
mach_num = [size(pro_time1, 1); size(pro_time2, 1)];

%% 数据提取和合并
% 1. 提取并合并第一列为 mach_rank
num_cols = length(pro_time1(:,1));
mach_rank = [pro_time1(:,1)'; [pro_time2(:,1)', zeros(1, num_cols - length(pro_time2(:,1)))]];
wo_num = 10 * (mach_rank ~= 0);

% 2. 提取处理时间到 c1 和 c2
% 处理时间位于列 3, 5, 7, ..., 21
c1 = pro_time1(:, 3:2:end);  % 从 pro_time1 提取
c2 = pro_time2(:, 3:2:end);  % 从 pro_time2 提取

% 3. 将 c1 和 c2 合并为胞组 pro_time
pro_time = {c1; c2};





%% 显示结果
disp('job_rank:'); disp(job_rank);
disp('ope_rank:'); disp(ope_rank);
disp('pro_time1 (工厂1的记录，每行一条记录):');
disp(pro_time1);
disp('pro_time2 (工厂2的记录，每行一条记录):');
disp(pro_time2);


disp('mach_rank:');
disp(mach_rank);
disp('c1:');
disp(c1);
disp('c2:');
disp(c2);
disp('pro_time{1}:');
disp(pro_time{1});
disp('pro_time{2}:');
disp(pro_time{2});

disp('mach_num:');
disp(mach_num);

disp('wo_num:');
disp(wo_num);
