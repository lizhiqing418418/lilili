% 打开文本文件

for file_num = 1:20

    % 生成读取文件名，例如 DW01.txt
    % 生成当前文件名
    base_name = sprintf('DW%02d', file_num);
    txt_filename = [base_name '.txt'];
    mat_filename = ['Instance_' base_name '.mat'];

    fid = fopen(txt_filename, 'r');
    if fid == -1
        error('无法打开文件 %s，请检查文件是否存在或路径是否正确', txt_filename);
    end
    
    % 跳过前五行说明
    for i = 1:5
        tline = fgetl(fid);
        if ~ischar(tline)
            error('文件不足五行，无法跳过前五行说明');
        end
    end
    
    all_data = {};
    
    % 逐行读取并转换为数值数组
    while ~feof(fid)
        line = fgetl(fid);
        if ischar(line)
            data_num = str2num(line);
            all_data{end+1} = data_num;
        end
    end
    fclose(fid);
    
    % 检查 all_data 是否为空
    % 修改后的代码段
    if isempty(all_data)
        warning('all_data 为空，没有数据可处理');
        job_infor = struct();
    else
        % 处理第一个元素并检查
        temp = process_data_small(all_data{1});
        if ~isstruct(temp) || ~isscalar(temp)
            error('第一个元素处理失败：返回非结构体或非标量结构体。');
        end
        job_infor = temp; % 初始化struct_data
        % 循环处理后续元素
        for k = 2:length(all_data)
            temp = process_data_small(all_data{k});
            if ~isscalar(temp) || ~isstruct(temp)
                fprintf('错误：i = %d 时，process_data 返回非标量或非结构体\n', i);
                break;
            end
            job_infor(k) = temp;
        end
    end
    
    
    % 计算 all_oper
    all_oper = length(job_infor);
    
    % 设置 fa_num
    fa_num = 2;
    
    % 计算 job_num
    job_ids = [job_infor.job_rank];
    job_num = max(job_ids);
    
    % 计算 ma_set_fa
    x = max(arrayfun(@(s) max(s.mach_rank(1,:)), job_infor));
    y = max(arrayfun(@(s) max(s.mach_rank(2,:)), job_infor));
    ma_set_fa = [x, y-x];
    
    % 创建 Fa_ma_set
    Fa_ma_set = {1:x, (x+1):y};
    
    % 设置 wo_num
    wo_num = 10;
    
    % 计算 ope_set
    ope_set = zeros(1, job_num);
    for j = 1:job_num
        ops = [job_infor(job_ids == j).ope_rank];
        ope_set(j) = max(ops);
    end


    % 保存到对应文件名的.mat文件
    save(mat_filename, 'Fa_ma_set', 'all_oper', 'fa_num', 'job_infor', 'job_num', 'ma_set_fa', 'ope_set', 'wo_num');
    fprintf('已成功处理并保存文件：%s\n', mat_filename);

end