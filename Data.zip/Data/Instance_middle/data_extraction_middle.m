%% 初始化数据
% 假设 data 已经被定义
data = [1 1 4 12 1 1 1 19 2 25 3 24 4 26 5 55 6 29 7 20 8 19 9 25 10 42 11 28 12 46 13 20 14 18 15 25 16 17 17 34 18 46 19 17 20 39 2 1 18 2 22 3 64 4 58 5 19 6 26 7 49 8 53 9 25 10 34 11 46 12 57 13 17 14 50 15 33 16 46 17 26 18 34 19 61 20 30 2 8 1 28 2 32 3 34 4 47 5 60 6 59 7 66 8 63 9 18 10 23 11 19 12 24 13 18 14 43 15 49 16 25 17 50 18 26 19 22 20 38 11 1 42 2 19 3 25 4 21 5 26 6 18 7 47 8 36 9 23 10 32 11 19 12 36 13 41 14 24 15 20 16 62 17 18 18 20 19 34 20 23 12 1 22 2 61 3 25 4 48 5 21 6 24 7 20 8 26 9 29 10 63 11 24 12 24 13 19 14 24 15 39 16 38 17 34 18 35 19 29 20 21 13 1 24 2 42 3 26 4 24 5 24 6 36 7 36 8 21 9 28 10 20 11 40 12 44 13 23 14 27 15 20 16 18 17 20 18 22 19 24 20 29 14 1 33 2 20 3 19 4 18 5 33 6 28 7 40 8 53 9 21 10 23 11 20 12 25 13 67 14 53 15 25 16 21 17 17 18 47 19 27 20 39 3 15 1 29 2 29 3 32 4 43 5 21 6 22 7 45 8 52 9 26 10 67 11 25 12 32 13 31 14 17 15 22 16 39 17 20 18 21 19 20 20 25 16 1 27 2 64 3 28 4 27 5 43 6 68 7 18 8 23 9 35 10 38 11 32 12 22 13 21 14 21 15 43 16 17 17 46 18 27 19 17 20 33 17 1 20 2 25 3 43 4 21 5 41 6 28 7 20 8 40 9 46 10 25 11 32 12 37 13 19 14 18 15 34 16 49 17 23 18 21 19 58 20 47 4 20 1 19 2 26 3 22 4 28 5 18 6 29 7 68 8 21 9 53 10 33 11 19 12 27 13 18 14 26 15 62 16 21 17 30 18 43 19 42 20 19 21 1 61 2 40 3 22 4 26 5 53 6 18 7 23 8 19 9 32 10 20 11 27 12 29 13 17 14 39 15 26 16 26 17 21 18 19 19 31 20 42];
% 注意：实际使用时，data 需要包含足够的数据以支持4个工厂和20个工人

%% 提取前两个数据
job_rank = data(1);    % 第1个数据，job_rank
ope_rank = data(2);    % 第2个数据，ope_rank
% data(3) 和 data(4) 未使用，但保留以保持格式

%% 设置工厂数量和工人数量
fa_num = 4;            % 工厂数量，从2增加到4
n_op = 20;             % 工人数量，从10增加到20
fa_rank=[1;2;3;4];
record_length = 1 + 2 * n_op;  % 记录长度：1个机器编号 + 20个工人及其处理时间 = 41

%% 初始化 pro_time 存储每个工厂的记录
pro_time_temporary = cell(fa_num, 1);  % 使用 cell 数组存储4个工厂的记录
%% 提取工厂1的第一条记录
% 第5个数据是工厂1的编号（固定为1），第6到第46个数据是工厂1的第一条记录
factory_id = data(5);  % 工厂1的编号
if factory_id ~= 1
    error('数据格式错误：第5个数据应为工厂1的编号（1）');
end

first_record = data(6:6 + record_length - 1);  % 第6到第46个数据
pro_time_temporary{1} = first_record;  % 存储到工厂1


%% 开始解析后续数据
j = 6 + record_length;  % 从第47个数据开始
current_factory = 1;    % 当前工厂编号，初始化为1

while j <= length(data)
    % 检查数据是否足够解析一条完整记录
    if j + record_length - 1 > length(data)
        warning('数据不足，无法按预期格式解析！');
        break;
    end
    
    % 提取当前数据后的段落
    next_segment = data(j + 1:j + record_length - 1);  % 接下来的40(48-88)个数据
    
    % 判断记录类型
    if all(next_segment(1:2:end) == (1:n_op))
        % 情况1：属于当前工厂
        % 格式：[机器编号 1 x1 2 x2 ... 20 x20]
        machine_id = data(j);  %47为机器编号
        record = [machine_id, next_segment];
        pro_time_temporary{current_factory} = [pro_time_temporary{current_factory}; record];
        j = j + record_length;  % 跳过41个元素
    else 
        % 情况2：新工厂的开始
        % 格式：[工厂编号 x 1 x1 2 x2 ... 20 x20]
        if j + record_length <= length(data)
            factory_id = data(j);  
            record_full = data(j + 1:j + record_length);  % 提取 [1 x1 2 x2 ... 20 x20]
            %因为j+1为机器编号
            
            % 验证工厂编号是否连续且格式正确
            if factory_id == current_factory + 1 && ...
               factory_id <= fa_num && ...
               all(record_full(2:2:end) == (1:n_op))
                current_factory = factory_id;  % 更新当前工厂
                pro_time_temporary{current_factory} = [pro_time_temporary{current_factory}; record_full];
                j = j + record_length + 1;  % 跳过42个元素（包括工厂编号）
            else
                warning('数据格式错误：工厂编号不连续或格式不符！');
                break;
            end
        else
            warning('数据不足，无法解析新工厂的记录！');
            break;
        end
    end
end




%% 提取 mach_rank 和 wo_num
mach_rank = zeros(fa_num, max(cellfun(@(x) size(x, 1), pro_time_temporary)));  % 初始化机器编号矩阵
wo_num = zeros(fa_num, 1);  % 初始化每个工厂的工人总数
for i = 1:fa_num
    if ~isempty(pro_time_temporary{i})
        % 提取每个工厂的机器编号
        mach_rank(i, 1:size(pro_time_temporary{i}, 1)) = pro_time_temporary{i}(:, 1)';
        
    end
end

% 计算工人总数：每台机器有 n_op 个工人
wo_num = n_op * (mach_rank ~=0);

%% 提取处理时间 c1, c2, c3, c4
pro_time = cell(fa_num, 1);  % 使用 cell 数组存储每个工厂的处理时间
for i = 1:fa_num
    if ~isempty(pro_time_temporary{i})
        % 提取处理时间，列 3, 5, 7, ..., 41
        pro_time{i} = pro_time_temporary{i}(:, 3:2:end);
    else
        pro_time{i} = [];  % 如果工厂没有记录，设为空
    end
end

%% 显示结果（可选）
disp('job_rank:'); disp(job_rank);
disp('ope_rank:'); disp(ope_rank);
for i = 1:fa_num
    disp(['pro_time_temporary' num2str(i) ':']);  % 显示每个工厂的完整记录
    disp(pro_time_temporary{i});
end
disp('mach_rank:');
disp(mach_rank);
for i = 1:fa_num
    disp(['pro_time' num2str(i) ':']);  % 显示每个工厂的处理时间
    disp(pro_time{i});
end
disp('wo_num:');
disp(wo_num);