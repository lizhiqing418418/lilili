function result = process_data_middle(data)
    %% 提取前两个数据
job_rank = data(1);    % 第1个数据，job_rank
ope_rank = data(2);    % 第2个数据，ope_rank
% data(3) 和 data(4) 未使用，但保留以保持格式

%% 设置工厂数量和工人数量
fa_num = 4;            % 工厂数量，从2增加到4
n_op = 20;             % 工人数量，从10增加到20
fa_rank=[1;2;3;4];
record_length = 1 + 2 * n_op;  % 记录长度：1个机器编号 + 20个工人及其处理时间 = 41

%% 初始化 pro_time 存储每个工厂的记录
pro_time_temporary = cell(fa_num, 1);  % 使用 cell 数组存储4个工厂的记录
%% 提取工厂1的第一条记录
% 第5个数据是工厂1的编号（固定为1），第6到第46个数据是工厂1的第一条记录
factory_id = data(5);  % 工厂1的编号
if factory_id ~= 1
    error('数据格式错误：第5个数据应为工厂1的编号（1）');
end

first_record = data(6:6 + record_length - 1);  % 第6到第46个数据
pro_time_temporary{1} = first_record;  % 存储到工厂1


%% 开始解析后续数据
j = 6 + record_length;  % 从第47个数据开始
current_factory = 1;    % 当前工厂编号，初始化为1

while j <= length(data)
    % 检查数据是否足够解析一条完整记录
    if j + record_length - 1 > length(data)
        warning('数据不足，无法按预期格式解析！');
        break;
    end
    
    % 提取当前数据后的段落
    next_segment = data(j + 1:j + record_length - 1);  % 接下来的40(48-88)个数据
    
    % 判断记录类型
    if all(next_segment(1:2:end) == (1:n_op))
        % 情况1：属于当前工厂
        % 格式：[机器编号 1 x1 2 x2 ... 20 x20]
        machine_id = data(j);  %47为机器编号
        record = [machine_id, next_segment];
        pro_time_temporary{current_factory} = [pro_time_temporary{current_factory}; record];
        j = j + record_length;  % 跳过41个元素
    else 
        % 情况2：新工厂的开始
        % 格式：[工厂编号 x 1 x1 2 x2 ... 20 x20]
        if j + record_length <= length(data)
            factory_id = data(j);  
            record_full = data(j + 1:j + record_length);  % 提取 [1 x1 2 x2 ... 20 x20]
            %因为j+1为机器编号
            
            % 验证工厂编号是否连续且格式正确
            if factory_id == current_factory + 1 && ...
               factory_id <= fa_num && ...
               all(record_full(2:2:end) == (1:n_op))
                current_factory = factory_id;  % 更新当前工厂
                pro_time_temporary{current_factory} = [pro_time_temporary{current_factory}; record_full];
                j = j + record_length + 1;  % 跳过42个元素（包括工厂编号）
            else
                warning('数据格式错误：工厂编号不连续或格式不符！');
                break;
            end
        else
            warning('数据不足，无法解析新工厂的记录！');
            break;
        end
    end
end




%% 提取 mach_rank 和 wo_num
mach_rank = zeros(fa_num, max(cellfun(@(x) size(x, 1), pro_time_temporary)));  % 初始化机器编号矩阵
wo_num = zeros(fa_num, 1);  % 初始化每个工厂的工人总数
for i = 1:fa_num
    if ~isempty(pro_time_temporary{i})
        % 提取每个工厂的机器编号
        mach_rank(i, 1:size(pro_time_temporary{i}, 1)) = pro_time_temporary{i}(:, 1)';
    end
end

% 计算工人总数：每台机器有 n_op 个工人
wo_num = n_op * (mach_rank ~=0);

%% 提取处理时间
pro_time = cell(fa_num, 1);  % 使用 cell 数组存储每个工厂的处理时间
for i = 1:fa_num
    if ~isempty(pro_time_temporary{i})
        % 提取处理时间，列 3, 5, 7, ..., 41
        pro_time{i} = pro_time_temporary{i}(:, 3:2:end);
    else
        pro_time{i} = [];  % 如果工厂没有记录，设为空
    end
end

% 计算 mach_num
mach_num = [size(pro_time{1}, 1); size(pro_time{2},1);size(pro_time{3},1);size(pro_time{4},1)];
c1=pro_time{1};
c2=pro_time{2};
c3=pro_time{3};
c4=pro_time{4};
pro_time={{c1;c2;c3;c4}};
    % 返回结果
    result = struct('job_rank', job_rank, ...
                    'ope_rank', ope_rank, ...
                    'fa_num', fa_num, ...
                    'fa_rank', fa_rank, ...
                    'mach_num', mach_num, ...
                    'mach_rank', mach_rank, ...
                    'wo_num', wo_num, ...
                    'pro_time', pro_time);
end
