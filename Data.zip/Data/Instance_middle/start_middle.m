% 打开文本文件

for file_num = 21:40

    % 生成读取文件名，例如 DW01.txt
    % 生成当前文件名
    base_name = sprintf('DW%02d', file_num);
    txt_filename = [base_name '.txt'];
    mat_filename = ['Instance_' base_name '.mat'];

    fid = fopen(txt_filename, 'r');
    if fid == -1
        error('无法打开文件 %s，请检查文件是否存在或路径是否正确', txt_filename);
    end
    
    % 跳过前五行说明
    for i = 1:5
        tline = fgetl(fid);
        if ~ischar(tline)
            error('文件不足五行，无法跳过前五行说明');
        end
    end
    
    all_data = {};
    
    % 逐行读取并转换为数值数组
    while ~feof(fid)
        line = fgetl(fid);
        if ischar(line)
            data_num = str2num(line);
            all_data{end+1} = data_num;
        end
    end
    fclose(fid);
    
    % 检查 all_data 是否为空
    % 修改后的代码段
    if isempty(all_data)
        warning('all_data 为空，没有数据可处理');
        job_infor = struct();
    else
        % 处理第一个元素并检查
        temp = process_data_middle(all_data{1});
        if ~isstruct(temp) || ~isscalar(temp)
            error('第一个元素处理失败：返回非结构体或非标量结构体。');
        end
        job_infor = temp; % 初始化struct_data
        % 循环处理后续元素
        for k = 2:length(all_data)
            temp = process_data_middle(all_data{k});
            if ~isscalar(temp) || ~isstruct(temp)
                fprintf('错误：i = %d 时，process_data 返回非标量或非结构体\n', i);
                break;
            end
            job_infor(k) = temp;
        end
    end
    
    
    % 计算 all_oper
    all_oper = length(job_infor);
    
    % 设置 fa_num
    fa_num = 4;
    
    % 计算 job_num
    job_ids = [job_infor.job_rank];
    job_num = max(job_ids);
    
    % 计算 ma_set_fa 各个工厂机器数
    %第一个工厂最大最小
    max1 = max(arrayfun(@(s) max(s.mach_rank(1,:)), job_infor));
    min1 = min(arrayfun(@(s) min(s.mach_rank(1, s.mach_rank(1,:) > 0)), job_infor));
    %第二个工厂最大最小
    max2 = max(arrayfun(@(s) max(s.mach_rank(2,:)), job_infor));
    min2 = min(arrayfun(@(s) min(s.mach_rank(2, s.mach_rank(2,:) > 0)), job_infor));
    %第三个工厂最大最小
    max3 = max(arrayfun(@(s) max(s.mach_rank(3,:)), job_infor));
    min3 = min(arrayfun(@(s) min(s.mach_rank(3, s.mach_rank(3,:) > 0)), job_infor));
    %第四个工厂最大最小
    max4 = max(arrayfun(@(s) max(s.mach_rank(4,:)), job_infor));
    min4 = min(arrayfun(@(s) min(s.mach_rank(4, s.mach_rank(4,:) > 0)), job_infor));
    
    % 计算 ma_set_fa 各个工厂机器数
    ma_set_fa = [max1-min1+1, max2-min2+1,max3-min3+1,max4-min4+1];
    
    % 创建 Fa_ma_set 计算各个工厂机器编号
    Fa_ma_set = {1:max1, min2:max2,min3:max3,min4:max4};
    
    % 设置 wo_num
    wo_num = 20;
    
    % 计算 ope_set
    ope_set = zeros(1, job_num);
    for j = 1:job_num
        ops = [job_infor(job_ids == j).ope_rank];
        ope_set(j) = max(ops);
    end

    
    % 保存到对应文件名的.mat文件
    save(mat_filename, 'Fa_ma_set', 'all_oper', 'fa_num', 'job_infor', 'job_num', 'ma_set_fa', 'ope_set', 'wo_num');
    fprintf('已成功处理并保存文件：%s\n', mat_filename);

end