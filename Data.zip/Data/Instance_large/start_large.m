for file_num = 41:50
    % 生成文件名
    base_name = sprintf('DW%02d', file_num);
    txt_filename = [base_name '.txt'];
    mat_filename = ['Instance_' base_name '.mat'];

    % 打开文件
    fid = fopen(txt_filename, 'r');
    if fid == -1
        error('无法打开文件 %s，请检查文件是否存在或路径是否正确', txt_filename);
    end
    
    % 跳过前五行
    for i = 1:5
        tline = fgetl(fid);
        if ~ischar(tline)
            error('文件不足五行，无法跳过前五行说明');
        end
    end
    
    % 读取数据
    all_data = {};
    while ~feof(fid)
        line = fgetl(fid);
        if ischar(line)
            data_num = str2num(line);
            all_data{end+1} = data_num;
        end
    end
    fclose(fid);
    
    % 处理数据
    if isempty(all_data)
        warning('all_data 为空，没有数据可处理');
        job_infor = struct();
    else
        % 使用 process_data_large 处理
        job_infor = process_data_large(all_data{1});
        for k = 2:length(all_data)
            job_infor(k) = process_data_large(all_data{k});
        end
    end
    
    % 计算操作总数
    all_oper = length(job_infor);
    
    % 获取工厂数量
    if ~isempty(job_infor)
        fa_num = job_infor(1).fa_num;  % 从 job_infor 获取，通常为6
    else
        fa_num = 6;  % 默认值
    end
    
    % 计算作业总数
    job_ids = [job_infor.job_rank];
    job_num = max(job_ids);
    
    % 计算 ma_set_fa 和 Fa_ma_set（适用于6个工厂）
    ma_set_fa = zeros(1, fa_num);
    Fa_ma_set = cell(1, fa_num);
    for f = 1:fa_num
        all_mach = [];
        for k = 1:length(job_infor)
            % 提取非零机器编号
            mach = job_infor(k).mach_rank(f, job_infor(k).mach_rank(f, :) > 0);
            all_mach = [all_mach, mach];
        end
        if ~isempty(all_mach)
            min_mach = min(all_mach);
            max_mach = max(all_mach);
            ma_set_fa(f) = max_mach - min_mach + 1;
            Fa_ma_set{f} = min_mach:max_mach;
        else
            ma_set_fa(f) = 0;
            Fa_ma_set{f} = [];
        end
    end
    
    % 设置每台机器的工人数量
    wo_num = 30;  % 大规模数据，每台机器30个工人
    
    % 计算每个作业的操作数量
    ope_set = zeros(1, job_num);
    for j = 1:job_num
        ops = [job_infor(job_ids == j).ope_rank];
        ope_set(j) = max(ops);
    end
    
    % 保存结果
    save(mat_filename, 'Fa_ma_set', 'all_oper', 'fa_num', 'job_infor', 'job_num', 'ma_set_fa', 'ope_set', 'wo_num');
    fprintf('已成功处理并保存文件：%s\n', mat_filename);
end
